import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    globals: true,
    environment: 'node',
    include: ['src/**/*.test.ts'],
    setupFiles: ['dotenv/config'],
    testTimeout: 20_000,
    pool: 'threads',
  },
});
